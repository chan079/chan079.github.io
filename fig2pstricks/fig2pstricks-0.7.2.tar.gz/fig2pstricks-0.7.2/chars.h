#include <stdio.h>
#include <stdlib.h>

#ifndef __chars_h
#define __chars_h

/**********

     any mode
  T  text only
  M  math only
  t  enclose by '{\tt ' and '}' in text mode

**********/

#define MODE_NULL 0
#define MODE_BOTH 1
#define MODE_TEXT 2
#define MODE_MATH 3

typedef struct {
    int   mode;  /* 0: null, 1: both, 2: text, 3: math */
    char *text;
    char *math;
    char *equi;
    int   need;  /* 0: nothing, 1: textcomp, 2: fontenc[T1] 3: fontenc[T4] */
} char_info_t;

static const char *_pkg_needed[4] = {
    NULL,
    "\\usepackage{textcomp}",
    "\\usepackage[T1]{fontenc}",
    "\\usepackage[T4]{fontenc}"
};

static const char_info_t _char_info[256] = {
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0x00 */
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0x08 */
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0x10 */
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0x18 */
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_BOTH, " ", "\\;", " ",  0 }, /* 0x20 */
    { MODE_BOTH, "!",  "!",  "!",  0 },
    { MODE_BOTH, "\"", "\"", "\"", 0 },
    { MODE_BOTH, "\\#",  "\\#",  "#",  0 },
    { MODE_BOTH, "\\$", "\\$", "$", 0 },
    { MODE_BOTH, "\\%%", "\\%%", "%%", 0 },
    { MODE_BOTH, "\\&", "\\&", "&", 0 },
    { MODE_BOTH, "'",  "'",  "'",  0 },
    { MODE_BOTH, "(",  "(",  "(",  0 }, /* 0x28 */
    { MODE_BOTH, ")",  ")",  ")",  0 },
    { MODE_BOTH, "*",  "*",  "*",  0 },
    { MODE_BOTH, "+",  "+",  "+",  0 },
    { MODE_BOTH, ",",  ",",  ",",  0 },
    { MODE_BOTH, "-",  "-",  "-",  0 },
    { MODE_BOTH, ".",  ".",  ".",  0 },
    { MODE_BOTH, "/",  "/",  "/",  0 },
    { MODE_BOTH, "0",  "0",  "0",  0 }, /* 0x30 */
    { MODE_BOTH, "1",  "1",  "1",  0 },
    { MODE_BOTH, "2",  "2",  "2",  0 },
    { MODE_BOTH, "3",  "3",  "3",  0 },
    { MODE_BOTH, "4",  "4",  "4",  0 },
    { MODE_BOTH, "5",  "5",  "5",  0 },
    { MODE_BOTH, "6",  "6",  "6",  0 },
    { MODE_BOTH, "7",  "7",  "7",  0 },
    { MODE_BOTH, "8",  "8",  "8",  0 }, /* 0x38 */
    { MODE_BOTH, "9",  "9",  "9",  0 },
    { MODE_BOTH, ":",  ":",  ":",  0 },
    { MODE_BOTH, ";",  ";",  ";",  0 },
    { MODE_BOTH, "\\textless ", "<", "<", 0 },
    { MODE_BOTH, "=",  "=",  "=",  0 },
    { MODE_MATH, "\\textgreater ", ">", "<", 0 },
    { MODE_BOTH, "?",  "?",  "?",  0 },
    { MODE_BOTH, "@",  "@",  "@",  0 }, /* 0x40 */
    { MODE_BOTH, "A",  "A",  "A",  0 },
    { MODE_BOTH, "B",  "B",  "B",  0 },
    { MODE_BOTH, "C",  "C",  "C",  0 },
    { MODE_BOTH, "D",  "D",  "D",  0 },
    { MODE_BOTH, "E",  "E",  "E",  0 },
    { MODE_BOTH, "F",  "F",  "F",  0 },
    { MODE_BOTH, "G",  "G",  "G",  0 },
    { MODE_BOTH, "H",  "H",  "H",  0 }, /* 0x48 */
    { MODE_BOTH, "I",  "I",  "I",  0 },
    { MODE_BOTH, "J",  "J",  "J",  0 },
    { MODE_BOTH, "K",  "K",  "K",  0 },
    { MODE_BOTH, "L",  "L",  "L",  0 },
    { MODE_BOTH, "M",  "M",  "M",  0 },
    { MODE_BOTH, "N",  "N",  "N",  0 },
    { MODE_BOTH, "O",  "O",  "O",  0 },
    { MODE_BOTH, "P",  "P",  "P",  0 }, /* 0x50 */
    { MODE_BOTH, "Q",  "Q",  "Q",  0 },
    { MODE_BOTH, "R",  "R",  "R",  0 },
    { MODE_BOTH, "S",  "S",  "S",  0 },
    { MODE_BOTH, "T",  "T",  "T",  0 },
    { MODE_BOTH, "U",  "U",  "U",  0 },
    { MODE_BOTH, "V",  "V",  "V",  0 },
    { MODE_BOTH, "W",  "W",  "W",  0 },
    { MODE_BOTH, "X",  "X",  "X",  0 }, /* 0x58 */
    { MODE_BOTH, "Y",  "Y",  "Y",  0 },
    { MODE_BOTH, "Z",  "Z",  "Z",  0 },
    { MODE_BOTH, "[",  "[",  "[",  0 },
    { MODE_TEXT, "\\textbackslash ", NULL, "\\", 0 },
    { MODE_BOTH, "]",  "]",  "]",  0 },
    { MODE_TEXT, "\\textasciicircum",  NULL, "^",  0 },
    { MODE_BOTH, "\\_", "\\_", "_", 0 },
    { MODE_BOTH, "`",  "`",  "`",  0 }, /* 0x60 */
    { MODE_BOTH, "a",  "a",  "a",  0 },
    { MODE_BOTH, "b",  "b",  "b",  0 },
    { MODE_BOTH, "c",  "c",  "c",  0 },
    { MODE_BOTH, "d",  "d",  "d",  0 },
    { MODE_BOTH, "e",  "e",  "e",  0 },
    { MODE_BOTH, "f",  "f",  "f",  0 },
    { MODE_BOTH, "g",  "g",  "g",  0 },
    { MODE_BOTH, "h",  "h",  "h",  0 }, /* 0x68 */
    { MODE_BOTH, "i",  "i",  "i",  0 },
    { MODE_BOTH, "j",  "j",  "j",  0 },
    { MODE_BOTH, "k",  "k",  "k",  0 },
    { MODE_BOTH, "l",  "l",  "l",  0 },
    { MODE_BOTH, "m",  "m",  "m",  0 },
    { MODE_BOTH, "n",  "n",  "n",  0 },
    { MODE_BOTH, "o",  "o",  "o",  0 },
    { MODE_BOTH, "p",  "p",  "p",  0 }, /* 0x70 */
    { MODE_BOTH, "q",  "q",  "q",  0 },
    { MODE_BOTH, "r",  "r",  "r",  0 },
    { MODE_BOTH, "s",  "s",  "s",  0 },
    { MODE_BOTH, "t",  "t",  "t",  0 },
    { MODE_BOTH, "u",  "u",  "u",  0 },
    { MODE_BOTH, "v",  "v",  "v",  0 },
    { MODE_BOTH, "w",  "w",  "w",  0 },
    { MODE_BOTH, "x",  "x",  "x",  0 }, /* 0x78 */
    { MODE_BOTH, "y",  "y",  "y",  0 },
    { MODE_BOTH, "z",  "z",  "z",  0 },
    { MODE_BOTH, "\\textbraceleft ", "\\}", "}", 0 },
    { MODE_BOTH, "|",  "|",  "|",  0 },
    { MODE_BOTH, "\\textbraceright ", "\\}", "}", 0 },
    { MODE_TEXT, "\\textasciitilde ", NULL, "~", 0 },
    { MODE_BOTH, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0x80 */
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0x88 */
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0x90 */
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0x98 */
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 },
    { MODE_NULL, NULL, NULL, NULL, 0 }, /* 0xa0 */
    { MODE_BOTH, "i",  "i",  "i",  0 },
    { MODE_TEXT, "\\textcent ", NULL, "c", 1 },
    { MODE_BOTH, "\\pounds ", "\\pounds ", "L", 0 },
    { MODE_TEXT, "\\textcurrency ", NULL, "*", 1 },
    { MODE_TEXT, "\\textyen ", NULL, "Y", 1 },
    { MODE_BOTH, "|",  "|",  "|", 0 },
    { MODE_BOTH, "\\S", "\\S", "S", 0 },
    { MODE_BOTH, "\"", "\"", "\"", 0 }, /* 0xa8 */
    { MODE_BOTH, "@", "@", "@", 0 },
    { MODE_TEXT, "\\textordfeminine ", NULL, "a", 0 },
    { MODE_TEXT, "\\guillemotleft ", NULL, "<", 2 },
    { MODE_TEXT, "\\textlnot ", NULL, "?", 1 },
    { MODE_BOTH, "--", "-", "-", 0 },
    { MODE_TEXT, "\\textregistered ", NULL, "R", 0 },
    { MODE_TEXT, "\\textasciimacron ", NULL, "-", 1 },
    { MODE_MATH, NULL, "{}^\\circ ", "o", 0 }, /* 0xb0 */
    { MODE_MATH, NULL, "\\pm", "+", 0 },
    { MODE_TEXT, "\\texttwosuperior ", NULL, "2", 1 },
    { MODE_TEXT, "\\textthreesuperior ", NULL, "3", 1 },
    { MODE_TEXT, "\\textasciiacute ", NULL, "'", 1 },
    { MODE_MATH, NULL, "\\mu ", 0 },
    { MODE_BOTH, "\\P ", "\\P ", 0 },
    { MODE_BOTH, "\\textperiodcentered ", "\\cdot ", 0},
    { MODE_BOTH, ",", ",", ",", 0}, /* 0xb8 */
    { MODE_TEXT, "\\textonesuperior ", NULL, "1", 1},
    { MODE_TEXT, "\\textordmasculine ", NULL, "o", 0},
    { MODE_TEXT, "\\guillemotright ", NULL, ">", 2},
    { MODE_TEXT, "\\textonequarter ", NULL, "4", 1},
    { MODE_TEXT, "\\textonehalf ", NULL, "2", 1},
    { MODE_TEXT, "\\textthreequarters ", NULL, "3", 1},
    { MODE_TEXT, "\\textquestiondown ", NULL, "?", 0},
    { MODE_TEXT, "\\`{A}", NULL, "A", 0 }, /* 0xc0 */
    { MODE_TEXT, "\\'{A}", NULL, "A", 0 },
    { MODE_TEXT, "\\^{A}", NULL, "A", 0 },
    { MODE_TEXT, "\\~{A}", NULL, "A", 0 },
    { MODE_TEXT, "\\\"{A}", NULL, "A", 0 },
    { MODE_TEXT, "\\AA ", NULL, "A", 0 },
    { MODE_TEXT, "\\AE ", NULL, "A", 0 },
    { MODE_TEXT, "\\c{C}", NULL, "C", 0 },
    { MODE_TEXT, "\\`{E}", NULL, "E", 0 }, /* 0xc8 */
    { MODE_TEXT, "\\'{E}", NULL, "E", 0 },
    { MODE_TEXT, "\\^{E}", NULL, "E", 0 },
    { MODE_TEXT, "\\\"{E}", NULL, "E", 0 },
    { MODE_TEXT, "\\`{I}", NULL, "I", 0 },
    { MODE_TEXT, "\\'{I}", NULL, "I", 0 },
    { MODE_TEXT, "\\^{I}", NULL, "I", 0 },
    { MODE_TEXT, "\\\"{I}", NULL, "I", 0 },
    { MODE_TEXT, "\\DH ", NULL, "D", 2 }, /* 0xd0 */
    { MODE_TEXT, "\\~N", NULL, "N", 0 },
    { MODE_TEXT, "\\`{O}", NULL, "O", 0 },
    { MODE_TEXT, "\\'{O}", NULL, "O", 0 },
    { MODE_TEXT, "\\^{O}", NULL, "O", 0 },
    { MODE_TEXT, "\\~{O}", NULL, "O", 0 },
    { MODE_TEXT, "\\\"{O}", NULL, "O", 0 },
    { MODE_MATH, NULL, "\\times ", "x", 0 },
    { MODE_TEXT, "\\O ", NULL, "O", 2 }, /* 0xd8 */
    { MODE_TEXT, "\\`{U}", NULL, "U", 0 },
    { MODE_TEXT, "\\'{U}", NULL, "U", 0 },
    { MODE_TEXT, "\\^{U}", NULL, "U", 0 },
    { MODE_TEXT, "\\\"{U}", NULL, "U", 0 },
    { MODE_TEXT, "\\'{Y}", NULL, "Y", 0 },
    { MODE_TEXT, "\\TH ", NULL, "P", 2 },
    { MODE_TEXT, "\\ss ", NULL, "s", 0 },
    { MODE_TEXT, "\\`{a}", NULL, "a", 0 }, /* 0xe0 */
    { MODE_TEXT, "\\'{a}", NULL, "a", 0 },
    { MODE_TEXT, "\\^{a}", NULL, "a", 0 },
    { MODE_TEXT, "\\~{a}", NULL, "a", 0 },
    { MODE_TEXT, "\\\"{a}", NULL, "a", 0 },
    { MODE_TEXT, "\\aa ", NULL, "a", 0 },
    { MODE_TEXT, "\\ae ", NULL, "a", 0 },
    { MODE_TEXT, "\\c{c}", NULL, "c", 0 },
    { MODE_TEXT, "\\`{e}", NULL, "e", 0 }, /* 0xe8 */
    { MODE_TEXT, "\\'{e}", NULL, "e", 0 },
    { MODE_TEXT, "\\^{e}", NULL, "e", 0 },
    { MODE_TEXT, "\\\"{e}", NULL, "e", 0 },
    { MODE_TEXT, "\\`{\\i}", NULL, "i", 0 },
    { MODE_TEXT, "\\'{\\i}", NULL, "i", 0 },
    { MODE_TEXT, "\\^{\\i}", NULL, "i", 0 },
    { MODE_TEXT, "\\\"{\\i}", NULL, "i", 0 },
    { MODE_TEXT, "\\dh ", NULL, "d", 2 }, /* 0xf0 */
    { MODE_TEXT, "\\~{n}", NULL, "n", 0 },
    { MODE_TEXT, "\\`{o}", NULL, "o", 0 },
    { MODE_TEXT, "\\'{o}", NULL, "o", 0 },
    { MODE_TEXT, "\\^{o}", NULL, "o", 0 },
    { MODE_TEXT, "\\~{o}", NULL, "o", 0 },
    { MODE_TEXT, "\\\"{o}", NULL, "o", 0 },
    { MODE_BOTH, "\\textdiv ", "\\div", "/", 0 },
    { MODE_TEXT, "\\o ", NULL, "o", 2 }, /* 0xf8 */
    { MODE_TEXT, "\\`{u}", NULL, "u", 0 },
    { MODE_TEXT, "\\'{u}", NULL, "u", 0 },
    { MODE_TEXT, "\\^{u}", NULL, "u", 0 },
    { MODE_TEXT, "\\\"{u}", NULL, "u", 0 },
    { MODE_TEXT, "\\'{y}", NULL, "y", 0 },
    { MODE_TEXT, "\\th ", NULL, "p", 2 },
    { MODE_TEXT, "\\\"{y}", NULL, "y", 0 }
};

static const char _chars[256] = {
    /*00*/ 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    /*10*/ 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    /*20*/ ' ','!','"','#','$','%','&','\'','(',')','*','+',',','-','.','/',
    /*30*/ '0','1','2','3','4','5','6','7', '8','9',':',';','<','=','>','?',
    /*40*/ '@','A','B','C','D','E','F','G', 'H','I','J','K','L','M','N','O',
    /*50*/ 'P','Q','R','S','T','U','V','W','X','Y','Z','[','\\',']','^','_',
    /*60*/ '`','a','b','c','d','e','f','g', 'h','i','j','k','l','m','n','o',
    /*70*/ 'p','q','r','s','t','u','v','w', 'x','y','z','{','|','}','~',0,
    /*80*/ 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    /*90*/ 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    /*a0*/ 0,'i','C','L','*','Y','|','S', '"','@','a','<',0,'-','R','-',
    /*b0*/ 'o','+','2','3','\'','m','P','.', ',','1','o','>','4','2','3','?',
    /*c0*/ 'A','A','A','A','A','A','A','C', 'E','E','E','E','I','I','I','I',
    /*d0*/ 'D','N','O','O','O','O','O','x', 'O','U','U','U','U','Y','P','s',
    /*e0*/ 'a','a','a','a','a','a','a','c', 'e','e','e','e','i','i','i','i',
    /*f0*/ 'd','n','o','o','o','o','o','/', 'o','u','u','u','u','y','p','y'
};

#endif
