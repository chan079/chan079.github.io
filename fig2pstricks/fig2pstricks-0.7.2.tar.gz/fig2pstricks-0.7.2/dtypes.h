/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#ifndef fig2pstricks_dtypes_h
#define fig2pstricks_dtypes_h

typedef struct {
    long value;
    char *name;
} COLOR;

typedef struct {
    char *origin;
    long length;
    char *curpos;
} STREAM;

typedef struct {
    int ls;
    int lw;
    int lc;
    int fc;
    int depth;
    int fs;
} STYLE;

typedef struct {
    int type;
    int style;
    double thickness;
    double width;
    double height;
} ARROW;

typedef struct tagNODE* NODE;

struct tagNODE {
    char *ptr;
    int depth;
    NODE prev;
    NODE next;
};

#endif
