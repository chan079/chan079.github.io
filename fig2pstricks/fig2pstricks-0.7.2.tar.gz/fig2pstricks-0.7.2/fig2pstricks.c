/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "version.h"
#include "fig2pstricks.h"
#include "helpmsgs.h"
#include "chars.h"

int going = -1, ndots = 0;
int math_label=0;
int resolution=1200;
int y_boundary;
STYLE prev_style;
int custom_color_equiv[MAXCOLOR];
int global_depth;
int math_mode = 0;
int latex_symbols = 0;
int pkgs_needed[4] = {0,0,0,0};

double def_unit = 1.0;
double def_scale = 0.8;

void print_depth_help(FILE *fp, char *appname)
{
    fprintf(fp, depth_help,
	    appname, appname, XFIG_SPECIAL, appname, XFIG_DEPTH);
}

void print_help(FILE *fp, char *appname)
{
    fprintf(fp, general_help, appname, appname);
}

void print_version(FILE *fp, char *appname, char *version)
{
    fprintf(fp, "%s %s\n", appname, version);
}

void error_exit(char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fprintf(stderr, "\n");
    exit(-1);
}

void proc_spec(FILE *fp, char *p)
{
    fprintf(stderr, "proc_spec( , %s)\n", p);
}

void check_next_arg1(char *opt, int i, int argc, char *next_arg, char **ptr)
{
    if (i<argc) {
	if (*next_arg=='-') error_exit("%s needs an argument.", opt);
	if (!*ptr) *ptr = next_arg;
	else error_exit("%s can be used only once.", opt);
    } else {
	error_exit("%s needs an argument.", opt);
    }
}

int get_one_scale(double *scale, char *ptr)
{
    int error = 0;
    char *p;
    *scale = strtod(ptr, &p);
    if (*p!='\0') error = 1;
    return error;
}

int get_one_unit(double *xcm, char *ptr) /* return 1 if error */
{
    int error = 0;
    char *p;
    *xcm = strtod(ptr, &p);
    if (!strcmp(p,"in")) {
	*xcm *= 2.54;
    } else if (!strcmp(p,"pt")) {
	*xcm /= 80.0;
    } else if (!strcmp(p,"mm")) {
	*xcm /= 10.0;
    } else if (strlen(p)>0 && strcmp(p,"cm")){
	error = 1;
    }
    return error;
}

int get_unit(double *xunit, double *yunit, char *ptr)
{
    double ux, uy;
    char *p, *where_comma;
    int ncomma;
    int error = 0;

    if (!ptr) {
	ux=def_unit;
	uy=def_unit;
    } else {
	p = ptr;
	ncomma = 0;
	while (*p) {
	    if (*p==',') { ncomma++; where_comma=p; }
	    p++;
	}
	if (ncomma==0) {
	    error = get_one_unit(&ux, ptr);
	    if (!error) {
		if (ux<=0.0) {
		    fprintf(stderr,
			    "Invalid unit in %s. Use default (%g) instead.\n",
			    ptr, def_unit);
		    ux = def_unit;
		}
		uy = ux;
	    }
	} else if (ncomma==1) {
	    *where_comma='\0';
	    error = get_one_unit(&ux, ptr);
	    *where_comma=',';
	    if (!error) {
		if (ux<=0.0) {
		    fprintf(stderr,
			    "Invalid x unit in %s. Use default (%g) instead.\n",
			    ptr, def_unit);
		    ux = def_unit;
		}
		if (!(error=get_one_unit(&uy, where_comma+1))) {
		    if (uy<=0.0) {
			fprintf(stderr,
				"Invalid y unit in %s. Use default (%g) instead.\n",
				ptr, def_unit);
			uy = def_unit;
		    }
		}
	    }
	} else {
	    error = 1;
	}
    }
    *xunit = ux;
    *yunit = uy;
    return error;
}

int get_scale(double *xscale, double *yscale, char *ptr)
{
    double sx, sy;
    char *p, *where_comma;
    int ncomma;
    int error;

    if (!ptr) {
	sx=def_scale;
	sy=def_scale;
    } else {
	p = ptr;
	ncomma = 0;
	while (*p) {
	    if (*p==',') { ncomma++; where_comma=p; }
	    p++;
	}
	if (ncomma==0) {
	    error = get_one_scale(&sx, ptr);
	    if (!error) {
		if (sx<=0.0) {
		    fprintf(stderr,
			    "Invalid scale in %s. Use default (%g) instead.\n",
			    ptr, def_scale);
		    sx = def_scale;
		}
		sy = sx;
	    }
	} else if (ncomma==1) {
	    *where_comma='\0';
	    error = get_one_scale(&sx, ptr);
	    *where_comma=',';
	    if (!error) {
		if (sx<=0.0) {
		    fprintf(stderr,
			    "Invalid x scale in %s. Use default (%g) instead.\n",
			    ptr, def_scale);
		    sx = def_scale;
		}
		if (!(error=get_one_scale(&sy, where_comma+1))) {
		    if (sy<=0.0) {
			fprintf(stderr,
				"Invalid y scale in %s. Use default (%g) instead.\n",
				ptr, def_scale);
			sy = def_scale;
		    }
		}
	    }
	} else {
	    error = 1;
	}
    }
    *xscale = sx;
    *yscale = sy;
    return error;
}

int _debug = 0;

int main(int argc, char *argv[])
{
    char *pszFileIn=NULL, *pszFileOut=NULL, *pszUnit=NULL, *pszScale=NULL,
	*pszPadding=NULL, *pszTitle=NULL, *pszFormat=NULL;
    char *src;
    FILE *fin, *fout;
    char *p, *q, *endptr;
    char buf[MAXSIZE+1], tok1[MAXSIZE+1], tok2[MAXSIZE+1];
    int i, id, pageno=0, coord=1, end_flag;
    int complete = 0, usedot = 0, prosper=0, obey_specials=1;
    int depth, prev_depth, ndepths, empty_page=0;
    int points = 10;
    long fpos, tmpl;
    double xunit, yunit, xscale=-1.0, yscale=-1.0;
    double padding=0.5;
    double mag;
    int ctbl[MAXCOLOR];
    int xmin=100000, xmax=-100000, ymin=100000, ymax=-100000;
    STREAM *sp;
    NODE node;

    global_depth = -1;

    // command line options
    for (i=1; i<argc; i++) {
	if (!strcmp("-o", argv[i])) {
	    i++;
	    check_next_arg1("-o", i, argc, argv[i], &pszFileOut);
	} else if (!strcmp("--test", argv[i])) {
	    return 0;
	} else if (!strcmp("-c", argv[i])) {
	    complete = 1;
	} else if (!strcmp("-u", argv[i])) {
	    i++;
	    check_next_arg1("-u", i, argc, argv[i], &pszUnit);
	} else if (!strcmp("-s", argv[i])) {
	    i++;
	    check_next_arg1("-s", i, argc, argv[i], &pszScale);
        } else if (!strcmp("-12", argv[i])) {
            points = 12;
        } else if (!strcmp("-11", argv[i])) {
            points = 11;
	} else if (!strcmp("-p", argv[i])) {
	    i++;
	    check_next_arg1("-p", i, argc, argv[i], &pszPadding);
	} else if (!strcmp("-T", argv[i])) {
	    i++;
	    check_next_arg1("-T", i, argc, argv[i], &pszTitle);
	} else if (!strcmp("-F", argv[i])) {
	    i++;
	    check_next_arg1("-F", i, argc, argv[i], &pszFormat);
	} else if (!strcmp("-v",argv[i]) || !strcmp("--version",argv[i])) {
	    print_version(stdout, APPNAME, VERSION);
	    return 0;
	} else if (!strcmp("-h",argv[i]) || !strcmp("--help",argv[i])) {
	    print_help(stdout, APPNAME);
	    return 0;
	} else if (!strcmp("--depth-help",argv[i])) {
	    print_depth_help(stdout, APPNAME);
	    return 0;
	} else if (!strcmp("-d",argv[i]) || !strcmp("--use-dot",argv[i])) {
	    usedot = 1;
	} else if (!strcmp("-m",argv[i]) || !strcmp("--math-label",argv[i])) {
	    math_label = 1;
	} else if (!strcmp("--ignore-specials",argv[i])) {
	    obey_specials = 0;
	} else if (!strcmp("--latex-symbols",argv[i])) {
	    latex_symbols = 1;
	} else if (!strcmp("--prosper",argv[i])) {
	    prosper = 1;
	    def_scale = 0.4;
	} else if (!strcmp("--debug",argv[i])) {
	    _debug = 1;
	} else if (!strcmp("--empty",argv[i])) {
	    empty_page = 1;
	} else if (*argv[i]=='-') {
	    error_exit("Invalid option: %s. Use -h or --help for help.",
		       argv[i]);
	} else {
	    if (!pszFileIn) pszFileIn = argv[i];
	    else error_exit("[%s] more than one input file.", pszFileIn);
	}
    }

    // unit
    if (get_unit(&xunit, &yunit, pszUnit))
	error_exit("Invalid unit specification: %s", pszUnit);
    if (get_scale(&xscale, &yscale, pszScale))
	error_exit("Invalid scale specification: %s", pszScale);
    xunit *= xscale;
    yunit *= yscale;
    if (pszPadding) {
	if (get_one_scale(&padding, pszPadding))
	    error_exit("Invalid padding specification: %s", pszPadding);
    }

    // input and output files
    if (pszFileIn) {
	if (!(fin=fopen(pszFileIn,"rb")))
		// should be "rb" for DOS compatibility
	    error_exit("Input file %s not exist.", pszFileIn);
    } else {
	int c;
	if (!(fin=tmpfile())) error_exit("Can not create emporary file");
	while ((c=fgetc(stdin))!=EOF) fputc(c, fin);
	rewind(fin);
    }

    if (pszFileOut) {
	if (!(fout=fopen(pszFileOut, "w"))) {
	    if (fin!=stdin) fclose(fin);
	    error_exit("Can't write file %s.", pszFileOut);
	}
    } else {
	fout = stdout;
    }

    // 1st line
    fgets(buf, MAXSIZE, fin);
    trims(buf);
    sscanf(buf, "%s %s", tok1, tok2);
    if (strcmp(tok1, "#FIG")) {
	if (fin!=stdin) fclose(fin);
	if (fout!=stdout) fclose(fout);
	error_exit("Input file %s is not a figure.", pszFileIn);
    }

    if (complete) {
	fprintf(fout, "\\documentclass[");
	if (points!=10) fprintf(fout, "%dpt,", points);
	if (prosper) {
	    fprintf(fout, "pdf,");
	    if (pszFormat) fprintf(fout, "%s,", pszFormat);
	    fprintf(fout, "slideColor,colorBG]{prosper}\n");
	} else {
	    fprintf(fout, "landscape,a4paper]{article}\n\
\\usepackage{fullpage}\n\
\\parindent=0pt\n");
	}
	fprintf(fout, "\\usepackage{times}\n\
\\usepackage{pstricks}\n\
\\usepackage{color}\n");
    }

    if (pszFileIn) texcomment(fout, "Input file name: %s", pszFileIn);
    texcomment(fout, "FIG version: %s", tok2);
    fgets(buf, MAXSIZE, fin); trims(buf);
    texcomment(fout, "Orientation: %s", buf);
    fgets(buf, MAXSIZE, fin); trims(buf);
    texcomment(fout, "Justification: %s", buf);
    fgets(buf, MAXSIZE, fin); trims(buf);
    texcomment(fout, "Units: %s", buf);
    if (strcmp(buf, "Inches")) { xunit/=2.54; yunit/=2.54; }
    fgets(buf, MAXSIZE, fin); trims(buf);
    texcomment(fout, "Paper size: %s", buf);
    fgets(buf, MAXSIZE, fin); trims(buf);
    texcomment(fout, "Magnification: %s", buf);
    mag = atof(buf);

    // Skip two lines: multiple-page, transparent color
    fgets(buf, MAXSIZE, fin);
    fgets(buf, MAXSIZE, fin);

    // Skip global comment
    do { fgets(buf, MAXSIZE, fin); } while (*buf=='#');

    // Resolution and coordinate system
    sscanf(buf, "%d %d", &resolution, &coord);
    texcomment(fout, "Resolution: %dppi", resolution);

    // Get filesize and prepare memory
    fpos = ftell(fin);
    fseek(fin, 0L, SEEK_END);
    tmpl = ftell(fin)-fpos;
    fseek(fin, fpos, SEEK_SET);
    src = (char*)malloc(tmpl+1);
    p = src;

    // read in the file to memory ignoring the comments.
    while (fgets(buf, MAXSIZE, fin)!=NULL) {
	if (*buf!='#') {
	    trims(buf);
	    q = buf;
	    while (*q) {
		while (isspace(*q)) q++;
		while (*q && !isspace(*q)) *(p++) = *(q++);
		*(p++) = ' ';
	    }
	}
    }
    *p = '\0';
    // close input file
    fclose(fin);

    // gather information on color, dimension and depths.  XFig
    // specials (as text object) to change depth are processed unless
    // --ignore-specials is used in the command line.  To set depth,
    // use "##%% depth=150" for example.  Note that the default depth
    // in R is 100.  A negative value of depth (eg. "##%% depth=-1")
    // nullifies the global depth change.

    node = NULL; // contains object depth and object pointer.
    trims(src);
    fill_colortbl(custom_color_equiv,-1);
    fill_colortbl(ctbl,-1);
    sp = topen(src, 0);
    end_flag = 0;
    while (!end_flag) {
	p = ttell(sp);
	id = tscani(sp);
	switch(id) {
	case OBJ_COLOR:
	    tskipw(sp, 2);
	    depth = INT_MAX;
	    break;
	case OBJ_ELLIPSE:
	    depth = preinfo_ellipse(ctbl,&xmin,&ymin,&xmax,&ymax,sp);
	    break;
	case OBJ_POLYLINE:
	    depth = preinfo_polyline(ctbl,&xmin,&ymin,&xmax,&ymax,sp);
	    break;
	case OBJ_SPLINE:
	    depth = preinfo_spline(ctbl,&xmin,&ymin,&xmax,&ymax,sp);
	    break;
	case OBJ_TEXT:
	    depth = preinfo_text(ctbl,&xmin,&ymin,&xmax,&ymax,sp);
	    break;
	case OBJ_ARC:
	    depth = preinfo_arc(ctbl,&xmin,&ymin,&xmax,&ymax,sp);
	    break;
	case OBJ_COMPOUND:
	    depth = preinfo_compound(ctbl,&xmin,&ymin,&xmax,&ymax,sp);
	    break;
	default:
	    twindup(sp);
	    break;
	}
	//printf("[%d]", depth);
	if (global_depth>=0 && obey_specials) depth=global_depth;
	prev_depth = depth;
	if (*(sp->curpos)) {
	    *(sp->curpos)='\0';
	    sp->curpos++;
	} else {
	    end_flag = 1;
	}
	if (node) append_node(node, depth, p);
	else node = create_node(depth, p);
    }
    if (_debug) fprintf(fout, "%%%% global_depth: %d\n", global_depth);

    proc_colortbl(fout, ctbl);

    if (pkgs_needed[1] || pkgs_needed[2] || pkgs_needed[3]) {
	if (complete) {
	    fprintf(fout, "\n%%%% Extra packages to handle texts:\n");
	    for (i=1; i<4; i++)
		if (pkgs_needed[i]) fprintf(fout, "%s\n", _pkg_needed[i]);
	} else {
	    fprintf(fout, "%%%% Include the following in the preamble:\n");
	    for (i=1; i<4; i++)
		if (pkgs_needed[i]) fprintf(fout, "%%%% %s\n", _pkg_needed[i]);
	    fprintf(fout, "%%%% End\n");
	}
    }

    if (complete) fprintf(fout, "\n\\begin{document}\n");

    y_boundary = ymin+ymax;

    ndepths = sort_by_depth(&node);
    //print_node(node);

    if (prosper) {
	if (ndepths>1 && global_depth>-1)
	    fprintf(fout, "\n\\overlays{%d}{\n", ndepths);
	fprintf(fout, "\\begin{slide}{%s}", pszTitle?pszTitle:"");
    }

    //printf("padding: %f -> ", padding);
    padding *= (double)resolution/2.45;
    //printf("%f\n", padding);

    fprintf(fout, "\n\\begin{pspicture}");
    fprint_xy_cm4(fout, (int)((xmin-padding)*xunit),
		  (int)((ymax+padding)*yunit),
		  (int)((y_boundary+0*padding)*yunit));
    fprint_xy_cm4(fout, (int)((xmax+padding)*xunit),
		  (int)((ymin-padding)*yunit),
		  (int)((y_boundary+0*padding)*yunit));

    fputc('\n', fout);
    if (xunit==yunit) fprintf(fout, "\\psset{unit=%gcm}", xunit);
    else fprintf(fout, "\\psset{xunit=%gcm,yunit=%gcm}", xunit, yunit);

    trewind(sp);
    init_style(&prev_style);

    prev_depth = -1;
    depth = 0;
    while (1) {
	trelink(sp, node->ptr, 0);
	if (prev_depth!=node->depth) {
	    fprintf(fout, "\n%%%%\n%%%% Depth: %d\n%%%%", node->depth);
	    prev_depth=node->depth;
	    if (node->depth!=INT_MAX) depth++;
	    if (prosper && global_depth>-1 && depth>1)
		fprintf(fout, "\n\\FromSlide{%d}", depth);
	}
	id = tscani(sp);
	switch(id) {
	case OBJ_COLOR:
	    if (_debug) fprintf(fout, "%%%% COLOR\n");
	    proc_color(fout, sp);
	    break;
	case OBJ_ELLIPSE: 
	    if (_debug) fprintf(fout, "%%%% ELLIPSE\n");
	    if (usedot) proc_ellipse_dot(fout, sp);
	    else proc_ellipse(fout, sp);
	    break;
	case OBJ_POLYLINE:
	    if (_debug) fprintf(fout, "%%%% POLYLINE\n");
	    proc_polyline(fout, sp);
	    break;
	case OBJ_SPLINE:
	    if (_debug) fprintf(fout, "%%%% SPLINE\n");
	    proc_spline(fout, sp);
	    break;
	case OBJ_TEXT:
	    if (_debug) fprintf(fout, "%%%% TEXT\n");
	    proc_text(fout, sp);
	    break;
	case OBJ_ARC:
	    if (_debug) fprintf(fout, "%%%% ARC\n");
	    proc_arc(fout, sp);
	    break;
	case OBJ_COMPOUND:
	    if (_debug) fprintf(fout, "%%%% COMPOUND\n");
	    proc_compound(fout, sp);
	    break;
	default:
	    twindup(sp);
	    break;
	}
	going = id;
	if (node==node->next) break;
	else node=node->next;
    }
    tclose(sp);
    free(src);

    fprintf(fout, "\n\\end{pspicture}\n");
    texcomment(fout, "End");

    if (prosper) {
	fprintf(fout, "\\end{slide}");
	if (ndepths>1 && global_depth>-1) fputc('}', fout);
	fputc('\n', fout);
    }

    if (empty_page) {
	if (complete) {
	    fprintf(fout, "\\thispagestyle{empty}\n");
	} else {
	    fprintf(fout, "%%%% \\thispagestyle{empty}\n");
	}
    }

    if (complete) {
	fprintf(fout, "\\end{document}\n");
    }

    // Close files
    delete_node(node);
    if (fout!=stdout) fclose(fout);

    if (!complete) {
	if (pkgs_needed[1] || pkgs_needed[2] || pkgs_needed[3]) {
	    printf("%%%% Include the following in the preamble (before \\begin{document}):\n");
	    for (i=1; i<4; i++)
		if (pkgs_needed[i]) printf("%%%%   %s\n", _pkg_needed[i]);
	}
    }

    return 0;
}
