/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "fig2pstricks.h"

extern int _debug;

int preinfo_compound(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp)
{
    int x0, x1, y0, y1, id;
    int d, depth=INT_MAX;
    x0 = tscani(sp);
    y0 = tscani(sp);
    x1 = tscani(sp);
    y1 = tscani(sp);
    id = tscani(sp);
    while (id!=-6) {
	switch(id) {
	case 0: tskipw(sp, 2); break;
	case 1: d=preinfo_ellipse(ctbl,xmin,ymin,xmax,ymax,sp); break;
	case 2: d=preinfo_polyline(ctbl,xmin,ymin,xmax,ymax,sp); break;
	case 3: d=preinfo_spline(ctbl,xmin,ymin,xmax,ymax,sp); break;
	case 4: d=preinfo_text(ctbl,xmin,ymin,xmax,ymax,sp); break;
	case 5: d=preinfo_arc(ctbl,xmin,ymin,xmax,ymax,sp); break;
	case 6: d=preinfo_compound(ctbl,xmin,ymin,xmax,ymax,sp); break;
	}
	id = tscani(sp);
	if (d<depth) depth=d;
    }
    if (x0<*xmin) *xmin=x0;
    if (y0<*ymin) *ymin=y0;
    if (x1>*xmax) *xmax=x1;
    if (y1>*ymax) *ymax=y1;
    return depth;
}

void proc_compound(FILE *fp, STREAM *sp)
{
    int x0, x1, y0, y1, id;
    x0 = tscani(sp);
    y0 = tscani(sp);
    x1 = tscani(sp);
    y1 = tscani(sp);
    id = tscani(sp);
    while (id!=-6) {
	switch(id) {
	case 0:
	    if (_debug) fprintf(fp, "%%%% COLOR\n");
	    proc_color(fp, sp);
	    break;
	case 1:
	    if (_debug) fprintf(fp, "%%%% ELLIPSE\n");
	    proc_ellipse(fp, sp);
	    break;
	case 2:
	    if (_debug) fprintf(fp, "%%%% POLYLINE\n");
	    proc_polyline(fp, sp);
	    break;
	case 3:
	    if (_debug) fprintf(fp, "%%%% SPLINE\n");
	    proc_spline(fp, sp);
	    break;
	case 4:
	    if (_debug) fprintf(fp, "%%%% TEXT\n");
	    proc_text(fp, sp);
	    break;
	case 5:
	    if (_debug) fprintf(fp, "%%%% ARC\n");
	    proc_arc(fp, sp);
	    break;
	case 6:
	    if (_debug) fprintf(fp, "%%%% COMPOUND\n");
	    proc_compound(fp, sp);
	    break;
	}
	id = tscani(sp);
    }
    if (_debug) fprintf(fp, "%%%% End COMPOUND\n");
}
