/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#ifndef fig2pstricks_color_h
#define fig2pstricks_color_h

COLOR pst_defcolor[] = {
    { 0x000000, "black" },
    { 0x404040, "darkgray" },
    { 0x808080, "gray" },
    { 0xc0c0c0, "lightgray" },
    { 0xffffff, "white" },
    { 0xff0000, "red" },
    { 0x00ff00, "green" },
    { 0x0000ff, "blue" },
    { 0x00ffff, "cyan" },
    { 0xff00ff, "magenta" },
    { 0xffff00, "yellow" }
};

COLOR fig_defcolor[] = {
    { 0x000000, "black" },   /*  0 */
    { 0x0000ff, "blue" },    /*  1 */
    { 0x00ff00, "green" },   /*  2 */
    { 0x00ffff, "cyan" },    /*  3 */
    { 0xff0000, "red" },     /*  4 */
    { 0xff00ff, "magenta" }, /*  5 */
    { 0xffff00, "yellow" },  /*  6 */
    { 0xffffff, "white" },   /*  7 */
    { 0x00008c, "blue4" },   /*  8 */
    { 0x0000ad, "blue3" },   /*  9 */
    { 0x0000ce, "blue2" },   /* 10 */
    { 0x84cfff, "ltblue" },  /* 11 */
    { 0x008e00, "green4" },  /* 12 */
    { 0x00a300, "green3" },  /* 13 */
    { 0x00cf00, "green2" },  /* 14 */
    { 0x008e8c, "cyan4" },   /* 15 */
    { 0x00aead, "cyan3" },   /* 16 */
    { 0x00cfce, "cyan2" },   /* 17 */
    { 0x8c0000, "red4" },    /* 18 */
    { 0xad0000, "red3" },    /* 19 */
    { 0xce0000, "red2" },    /* 20 */
    { 0x8c008c, "magenta4" },/* 21 */
    { 0xad00ad, "magenta3" },/* 22 */
    { 0xce00ce, "magenta2" },/* 23 */
    { 0x843000, "brown4" },  /* 24 */
    { 0x9c4100, "brown3" },  /* 25 */
    { 0xbd6100, "brown2" },  /* 26 */
    { 0xff8284, "pink4" },   /* 27 */
    { 0xff9e9c, "pink3" },   /* 28 */
    { 0xffbebd, "pink2" },   /* 29 */
    { 0xffdfde, "pink" },    /* 30 */
    { 0xffd700, "gold" }     /* 31 */
};

char *custom_color_prefix = "mycolor";

extern int custom_color_equiv[], color_tbl[];

#endif
