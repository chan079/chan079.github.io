#ifndef VERSION
#define VERSION "0.7.2"
#endif

#ifndef APPNAME
#define APPNAME "fig2pstricks"
#endif
