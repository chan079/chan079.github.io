/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "fig2pstricks.h"
#include "extern.h"

int prev_xrad=0, prev_yrad=0;

int preinfo_ellipse(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp)
{
    int i, n, x, y, cx, cy, rx, ry, depth;
    tskipw(sp, 3);
    into_colortbl(ctbl,tscani(sp)); // linecolor
    into_colortbl(ctbl,tscani(sp)); // fillcolor
    depth = tscani(sp);
    tskipw(sp, 5);
    cx = tscani(sp);
    cy = tscani(sp);
    rx = tscani(sp);
    ry = tscani(sp);
    x = cx-rx;
    y = cy-ry;
    if (x<*xmin) *xmin = x;
    if (y<*ymin) *ymin = y;
    x = cx+rx;
    y = cy+ry;
    if (x>*xmax) *xmax = x;
    if (y>*ymax) *ymax = y;
    tskipw(sp, 4);
    return depth;
}

void proc_ellipse(FILE *fp, STREAM *sp)
{
    int subtype, cx, cy, rx, ry, nchg, hasset=0;
    STYLE style;

    subtype = read_style(&style, sp);
    hasset = write_style(fp, &prev_style, &style);
    prev_style = style;
    psset_close(fp, hasset);

    tskipw(sp,2); // direction, angle
    cx = tscani(sp);
    cy = tscani(sp);
    rx = tscani(sp);
    ry = tscani(sp);
    tskipw(sp,4);

    fputc('\n', fp);
    if (rx==ry) {
	if (star_style(&style)) fprintf(fp, "\\qdisk");
	else fprintf(fp, "\\pscircle");
    } else {
	fprintf(fp, "\\psellipse");
    }
    fprint_xy(fp, cx, cy);
    if (rx==ry) fprintf(fp, "{%.1f}", unit2cm(rx));
    else fprintf(fp, "(%.1f,%.1f)", unit2cm(rx),unit2cm(ry));
}

void proc_ellipse_dot(FILE *fp, STREAM *sp)
{
    int subtype, cx, cy, rx, ry, nchg, hasset=0;
    STYLE style;

    subtype = read_style(&style, sp);
    hasset = write_style(fp, &prev_style, &style);

    tskipw(sp,2); // direction, angle
    cx = tscani(sp);
    cy = tscani(sp);
    rx = tscani(sp);
    ry = tscani(sp);
    if (prev_xrad!=rx || prev_yrad!=ry) {
	prev_xrad=rx;
	prev_yrad=ry;
	psset_if_nec(fp, &hasset);
	fprintf(fp, "dotscale=%.1f", unit2cm(rx)*16);
	if (rx!=ry) fprintf(fp, " %.1f", unit2cm(ry)*16);
    }
    if (hasset) {
	psset_if_nec(fp, &hasset);
	if (star_style(&style)) fprintf(fp, "dotstyle=*");
	else fprintf(fp, "dotstyle=o");
    }
    psset_close(fp, hasset);

    tskipw(sp,4);

    if (going!=1 || hasset || prev_style.depth!=style.depth) ndots = 0;
    prev_style = style;

    if (ndots==0) {
	fputc('\n', fp);
	fprintf(fp, "\\psdots");
    }
    fprint_xy(fp, cx, cy);
    ndots++;
}
