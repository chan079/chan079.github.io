#!/bin/sh

#### Don't run this.

H=fig2pstricks.h

cat <<EOF > $H
/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <limits.h>
/*#include <libgen.h>*/

EOF

for i in $*; do
    echo "#include \"$i.h\"" >> $H
done

cat <<EOF >> $H

#ifndef fig2pstricks_h
#define fig2pstricks_h


EOF

for i in *.c; do
    echo "" >> $H
    echo "/* file: $i */" >> $H
    grep -s -h -e "^[A-Za-z]" $i | \
	grep "(" | grep -v "main" | grep -v "\\\\n" | \
	while read line; do
	    echo "$line;"
    done >> $H
done

cat <<EOF >> $H

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)>(b)?(b):(a))

#define MAXSIZE 255
#define MAXCSIZE 63
#define MAXCOLOR 512

#define INT2CCN(n) ((n)-32)
#define RAD2DEG(r) ((r)*180/M_PI)

#define OBJ_COLOR    0
#define OBJ_ELLIPSE  1
#define OBJ_POLYLINE 2
#define OBJ_SPLINE   3
#define OBJ_TEXT     4
#define OBJ_ARC      5
#define OBJ_COMPOUND 6

#define UNIT_CM      0
#define UNIT_IN      1
#define UNIT_PT      2
#define UNIT_MM      3

#define XFIG_SPECIAL "##%% "
#define STRLEN_XFIG_SPECIAL 5
#define XFIG_DEPTH "depth="
#define STRLEN_XFIG_DEPTH 6

#endif

EOF
