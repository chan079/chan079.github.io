/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "fig2pstricks.h"

STREAM *topen(char *ptr, int n)
{
    STREAM *sp = (STREAM*)malloc(sizeof(STREAM));
    sp->origin = ptr;
    sp->curpos = ptr;
    if (!n) sp->length = strlen(ptr);
    else sp->length = n;
    return sp;
}

void tclose(STREAM *sp)
{
    free(sp);
}

void trelink(STREAM *sp, char *ptr, int n)
{
    sp->origin = ptr;
    sp->curpos = ptr;
    if (!n) sp->length = strlen(ptr);
    else sp->length = n;
}

void trewind(STREAM *sp)
{
    sp->curpos = sp->origin;
}

void twindup(STREAM *sp)
{
    sp->curpos = sp->origin + sp->length;
}

long tlength(STREAM *sp)
{
    return sp->length;
}

int tntell(STREAM *sp)
{
    return sp->curpos - sp->origin;
}

int ttellln(STREAM *sp)
{
    char *p = sp->origin;
    int n=1;
    while (p<sp->curpos) if (*p++=='\n') n++;
    return n;
}

char *ttell(STREAM *sp)
{
    return sp->curpos;
}

char *tsetpos(STREAM *sp, char *p)
{
    sp->curpos = p;
    return p;
}

void tseek(STREAM *sp, long npos, int whence)
{
    switch(whence) {
    case SEEK_SET: sp->curpos = sp->origin+npos; break;
    case SEEK_END: sp->curpos = sp->origin+whence+npos; break;
    case SEEK_CUR: sp->curpos += npos; break;
    }
}

int tsetnpos(STREAM *sp, int n)
{
    if (n<0) n=0;
    else if (n>=sp->length) n=sp->length-1;
    sp->curpos = sp->origin+n;
    return 0;
}

int tscani(STREAM *sp)
{
    char *nptr, *endptr;
    long num;
    num = strtol(sp->curpos, &endptr, 0);
    sp->curpos = endptr;
    return (int)num;
}

unsigned int tscanu(STREAM *sp)
{
    char *nptr, *endptr;
    long num;
    num = strtol(sp->curpos, &endptr, 0);
    sp->curpos = endptr;
    return (unsigned int)num;
}

double tscand(STREAM *sp)
{
    char *nptr, *endptr;
    double num;
    num = strtod(sp->curpos, &endptr);
    sp->curpos = endptr;
    return num;
}

char *tscans(char *ptr, STREAM *sp)
{
    char *p = sp->curpos;
    char *q = ptr;
    *ptr = '\0';
    while (*p && isspace(*p)) p++;

    if (*p=='"') {
	p++;
	while (*p!='"') {
	    if (*p=='\\') {
		p++;
		if (*p=='n') *q++ = '\n';
		else if (*p=='"') *q++ = '"';
		p++;
	    } else {
		*q++ = *p++;
	    }
	}
	p++;
    } else {
	while (*p && !isspace(*p)) *q++ = *p++;
    }
    *q = '\0';

    sp->curpos = p;
    return ptr;
}

char *tunscan(STREAM *sp)
{
    char *p0 = sp->origin;
    char *p = sp->curpos;
    while (p>p0 && isspace(*p)) p--;
    if (*p=='"') while (p>p0 && !(*p=='"' && *(p-1)=='\\')) p--;
    else while (p>p0 && !isspace(*p)) p--;
    while (p>p0 && isspace(*p)) p--;
    p++;
    sp->curpos = p;
    return p;
}

char *tnexttok(char *ptr, STREAM *sp) /* Does not proceed pointer */
{
    char *psave;
    psave = ttell(sp);
    tscans(ptr, sp);
    tsetpos(sp, psave);
    return ptr;
}

char *tskipw(STREAM *sp, int n)
{
    int i;
    char *p;
    p = sp->curpos;
    for (i=0; i<n; i++) {
	while (isspace(*p)) p++;
	while (*p && !isspace(*p)) p++;
    }
    sp->curpos = p;
    return p;
}
