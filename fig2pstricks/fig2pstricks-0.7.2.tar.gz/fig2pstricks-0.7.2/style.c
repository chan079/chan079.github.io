/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "fig2pstricks.h"

int read_style(STYLE *style, STREAM *stream)
{
    int subtype;
    subtype = tscani(stream);
    style->ls = tscani(stream);
    style->lw = tscani(stream);
    style->lc = tscani(stream);
    style->fc = tscani(stream);
    style->depth = tscani(stream);
    tskipw(stream, 1);
    style->fs = tscani(stream);
    tskipw(stream, 1);
    return subtype;
}

int write_style(FILE *fp, STYLE *prev, STYLE *cur)
{
    int hasset = 0;

    clean_style(cur);

    chkprev_linestyle(fp, &hasset, prev->ls, cur->ls, "linestyle");
    chkprev_thick(fp, &hasset, prev->lw, cur->lw, "linewidth");
    chkprev_color(fp, &hasset, prev->lc, cur->lc, "linecolor");

    if (cur->fs==-1) {
	chkprev_fillstyle(fp, &hasset, prev->fs, cur->fs, "fillstyle");
    } else if (cur->lc!=cur->fc) {
	chkprev_fillstyle(fp, &hasset, prev->fs, cur->fs,"fillstyle");
	chkprev_color(fp, &hasset, prev->fc, cur->fc, "fillcolor");
    }

    return hasset;
}

int star_style(STYLE *sty)
{
    return (sty->fs!=-1 && sty->lc==sty->fc);
}

void init_style(STYLE *sty)
{
    sty->ls = -2;
    sty->lw = -2;
    sty->lc = -2;
    sty->fc = -2;
    sty->depth = -2;
    sty->fs = -2;
}

void clean_style(STYLE *s)
{
    if (s->lw==0) {
	if (s->fs!=-1) {
	    s->lw=1;
	    s->lc=s->fc;
	}
    }
}
