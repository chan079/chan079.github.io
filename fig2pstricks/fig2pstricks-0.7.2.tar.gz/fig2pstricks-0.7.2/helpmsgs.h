#ifndef __help_messages_h
#define __help_messages_h

char *depth_help = "%s handles the levels (or depths, or overlays) of the\n\
objects based on the depths of the fig objects. So if you have used\n\
xfig to generate the fig files, set the depths correspondingly.\n\
Note that a smaller depth bring forward the corresponding object.\n\
\n\
However, R sets the depths of all the objects to 100, and there is no way\n\
to change it unless you hack the R source. So here I provide a work around\n\
of using a text object of fig.\n\
\n\
In %s, any text beginning with \"%s\" is regarded as a special\n\
string to control the depths of the objects following through. And in the\n\
current version of %s, only \"%s\" is recognized as proper\n\
control command. In short, you can bring forward the objects by doing in R:\n\
\n\
\ttext(x[1],y[1],\"##%%%% depth=80\",0)\n\
\n\
for example, and send them backward by\n\
\n\
\ttext(x[1],y[1],\"##%%%% depth=200\",0)\n\
\n\
for example. To nullify the previous depth setting and return back to 100,\n\
set depth to a negative number, e.g., write the string \"##%%%% depth=-1\"\n\
using 'text()' function. See R help for more on the R 'text()' command.\n";

char *general_help = "%s: A fig to pstricks converter\n\
Usage: %s [options] [input_file]\n\
Options:\n\
    -o FILE           Set output file to FILE, default=stdout\n\
    -c                Produce complete latex file\n\
    -u UNIT           Specify unit, (default=1cm)\n\
       or ux,uy       xunit is ux, yunit is uy (eg 1in,2.54cm)\n\
                      use in, cm or mm (default=cm)\n\
                      unit is unit*scale (cm)\n\
    -s SCALE          Scale factor is SCALE (default=0.8)\n\
       or sx,sy       x scale factor is sx, y scale factor is sy\n\
                      unit is unit*scale (cm).\n\
    -12               Add '12pt' in the document option.\n\
                      effective only when used with -c.\n\
    -11               Similar to -12 except that it adds '11pt'\n\
    -p PADDING        Padding in fraction of unit (default=0.5)\n\
    --prosper         Output with full Prosper support.\n\
    -T title          Set the slide title to title in prosper.\n\
                      Ignored in non-prosper mode\n\
    -F format         Prosper style format (default=default).\n\
                      One of frames, lignesbleues, azure, troispoints,\n\
                      contemporain, nuancegris, darkblue, alien glow,\n\
                      autumn, gyom, rico and default.\n\
                      Ignored in non-prosper mode.\n\
    -d, --use-dot     Convert ellipses to dots instead of ellipses\n\
    -m, --math-label  Use math (enclosed by two $'s) for labels\n\
    --empty           Append \\thispagestyle{empty} when -c is enabled\n\
                      This option is good for producing eps and pdf files\n\
    --latex-symbols   Convert characters to latex commands\n\
    --ignore-specials Ignore depth change specials\n\
                      See --depth-help option.\n\
    --depth-help      Help on bringing forward or sending backward objects.\n\
    -v, --version     Show version\n\
    -h, --help        Show this help\n";

#endif
