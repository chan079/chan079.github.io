/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "fig2pstricks.h"

#include "color.h"

extern int _debug;

long rgb2long(int r, int g, int b)
{
    long k = r;
    k <<= 16;
    k += g;
    k <<= 16;
    k += b;
    return k;
}

void long2rgb(long rgb, int *r, int *g, int *b)
{
    *b = rgb%256;
    rgb >>= 8;
    *g = rgb%256;
    rgb >>= 8;
    *r = rgb%256;
}

double col2f(int col)
{
    if (col==255) return 1.0;
    else return (double)col/256.0;
}

void chkprev_color(FILE*fp,int *hasset,int nprev,int nnow,char *keyname)
{
    int i;
    if (nprev!=nnow) {
	psset_if_nec(fp, hasset);
	fprintf(fp, "%s=", keyname);
	if (nnow==-1) i = 0;
	else i = custom_color_equiv[nnow];
	if (i>=0) {
	    fprintf(fp, "%s", pst_defcolor[i].name);
	} else {
	    if (nnow<32) fprintf(fp, "%s", fig_defcolor[nnow].name);
	    else fprintf(fp, "%s%d", custom_color_prefix, INT2CCN(nnow));
	}
    }
}

void proc_color(FILE *fp, STREAM *sp)
{
    int i, color_id, r, g, b;
    long col;
    char tmp[16];

    color_id = tscani(sp);
    col = strtol(tscans(tmp,sp)+1, NULL, 16);

    if (col>=0) {
	// check if same pstricks default color exists
	for (i=0; i<11; i++) {
	    if (col==pst_defcolor[i].value) {
		custom_color_equiv[color_id] = i;
		break;
	    }
	}
	// define new color if no default color exists
	if (i>=11)
	    define_new_color(fp, col, "%s%d", 
			     custom_color_prefix, INT2CCN(color_id));
    }
}

void latex_color_command(FILE *fp, int c)
{
    char buf[32];
    if (_debug) fprintf(fp, "%%%% color: %d\n", c);
    if (c<0) {
	strcpy(buf, "black");
    } else if (c<32) {
	strcpy(buf, fig_defcolor[c].name);
    } else {
	int i;
	i = custom_color_equiv[c];
	if (i>=0) strcpy(buf, pst_defcolor[i].name);
	else sprintf(buf, "%s%d", custom_color_prefix, INT2CCN(c));
    }
    if (strcmp("black", buf)) fprintf(fp, "\\color{%s}", buf);
}

char *color_name(char *color_name_buf, int c)
{
    if (c<0) {
	strcpy(color_name_buf, "black");
    } else if (c<32) {
	strcpy(color_name_buf, fig_defcolor[c].name);
    } else {
	int i;
	i = custom_color_equiv[c];
	if (i>=0) strcpy(color_name_buf, pst_defcolor[i].name);
	else sprintf(color_name_buf, "%s%d", 
		     custom_color_prefix, INT2CCN(c));
    }
    return color_name_buf;
}

void fprint_color_name(FILE *fp, int c)
{
    if (c<32) {
	fprintf(fp, "%s", fig_defcolor[c].name);
    } else {
	int i;
	i = custom_color_equiv[c];
	if (i>=0) fprintf(fp, "%s", pst_defcolor[i].name);
	else fprintf(fp, "%s%d", custom_color_prefix, INT2CCN(c));
    }
}

int in_colortbl(int *colortbl, int c)
{
    int *n;
    n = colortbl;
    while (*n>7 && *n<32) {
	if (c==*n) break;
	else n++;
    }
    if (*n>7 && *n<32) return 1;
    else return 0;
}

void into_colortbl(int *colortbl, int c)
{
    if (c>7 && c<32) {
	if (!in_colortbl(colortbl, c)) {
	    while (*colortbl>7 && *colortbl<32) colortbl++;
	    *colortbl = c;
	}
    }
}

void define_new_color(FILE *fp, long col, char *name, ...)
{
    int r, g, b, gray;
    va_list ap;

    long2rgb(col, &r, &g, &b);
    fputc('\n', fp);
    if (r==g && g==b) gray=1;
    else gray=0;

    va_start(ap, name);
    if (gray) fprintf(fp, "\\newgray{");
    else fprintf(fp, "\\newrgbcolor{");
    vfprintf(fp, name, ap);
    fputc('}', fp);
    va_end(ap);

    if (gray) fprintf(fp, "{%.2f}", col2f(r));
    else fprintf(fp, "{%.2f %.2f %.2f}", col2f(r), col2f(g), col2f(b));

    va_start(ap, name);
    fprintf(fp, "\\definecolor{");
    vfprintf(fp, name, ap);
    fputc('}', fp);
    va_end(ap);

    if (gray) fprintf(fp, "{gray}{%.2f}", col2f(r));
    else fprintf(fp, "{rgb}{%.2f,%.2f,%.2f}", col2f(r), col2f(g), col2f(b));
}

void proc_colortbl(FILE *fp, int *ctbl)
{
    while (*ctbl>7 && *ctbl<32) {
	define_new_color(fp,
			 fig_defcolor[*ctbl].value,
			 fig_defcolor[*ctbl].name);
	*ctbl++;
    }
}

void show_colortbl(char *fmt, int *ctbl)
{
    while (*ctbl>=11 && *ctbl<32) printf(fmt, *ctbl++);
}

void fill_colortbl(int *ctbl, int c)
{
    int i;
    for (i=0; i<MAXCOLOR; i++, ctbl++) *ctbl=c;
}
