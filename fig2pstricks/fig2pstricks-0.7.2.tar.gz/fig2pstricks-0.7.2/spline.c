/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "fig2pstricks.h"
#include "extern.h"

int preinfo_spline(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp)
{
    int i, n, fa, ba, x, y, depth;
    tskipw(sp, 3);
    into_colortbl(ctbl,tscani(sp)); // linecolor
    into_colortbl(ctbl,tscani(sp)); // fillcolor
    depth = tscani(sp);
    tskipw(sp, 4);
    fa = tscani(sp);
    ba = tscani(sp);
    n = tscani(sp);
    if (fa) tskipw(sp, 5);
    if (ba) tskipw(sp, 5);
    for (i=0; i<n; i++) {
	x = tscani(sp);
	y = tscani(sp);
	if (x<*xmin) *xmin=x;
	else if (x>*xmax) *xmax=x;
	if (y<*ymin) *ymin=y;
	else if (y>*ymax) *ymax=y;
    }
    tskipw(sp, n);
    return depth;
}

void proc_spline(FILE*fp, STREAM*sp)
{
    int i, fa, ba, npoints, subtype;
    int nx, ny;
    int hasset=0;
    STYLE style;

    subtype = read_style(&style, sp);
    hasset = write_style(fp, &prev_style, &style);
    prev_style = style;

    psset_close(fp, hasset);
    tskipw(sp, 1); // cap style
    fa = tscani(sp);
    ba = tscani(sp);
    npoints = tscani(sp);

    fputc('\n', fp);
    if (subtype%2) {
	fprintf(fp, "\\psccurve");
	if (star_style(&style)) fputc('*', fp);
	proc_arrows(fp, fa, ba, sp, 0);
    } else {
	fprintf(fp, "\\pscurve");
	if (star_style(&style)) fputc('*', fp);
	proc_arrows(fp, fa, ba, sp, 1);
    }

    for (i=0; i<npoints; i++) {
	nx = tscani(sp);
	ny = tscani(sp);
	fprint_xy(fp, nx, ny);
    }
    tskipw(sp, npoints);
}
