nobs <- 30
x <- rnorm(nobs,mean=3,sd=2)
y <- 25-3*x+rnorm(nobs,sd=5)
ls <- lm(y~x)
b <- ls$coefficients
xlim <- c(min(x),max(x))
xfig(file="leastsq.fig", onefile=T)
plot(x,y,type="n")
text(x[1],y[1],"##%% depth=80",0)
points(x,y,pch=16,col=4)
text(x[1],y[1],"##%% depth=60",0)
lines(xlim, b[1]+b[2]*xlim, lty=1, col=2, lwd=10)
##text(x[1],y[1],"##%% depth=-1",0)
dev.off()
