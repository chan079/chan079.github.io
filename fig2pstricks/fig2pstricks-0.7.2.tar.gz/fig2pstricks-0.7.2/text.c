/*
 * Copyright (c) 2004-20013 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "fig2pstricks.h"
#include "symbol.h"
#include "chars.h"
#include "extern.h"

char color_name_buf[32];
extern int global_depth;
extern int _debug;
extern int pkgs_needed[4];

int get_next_char(char *p, char **endptr)
{
    int n;
    char buf[4];
    if (*p=='\\') {
	p++;
	if (*p>='0' && *p<='7') {
	    strncpy(buf,p,3);
	    n = strtol(buf,NULL,8);
	    p+=3;
	} else {
	    n = (unsigned char) *(p++);
	}
    } else {
	n = (unsigned char) *(p++);
    }
    *endptr = p;
    return n;
}

void to_math_mode(FILE *fp)
{
    if (!math_mode) {
	math_mode = 1;
	fputc('$',fp);
    }
}

void to_text_mode(FILE *fp)
{
    if (math_mode) {
	math_mode = 0;
	fputc('$',fp);
    }
}

void print_tex_char(FILE *fp, int n)
{
    char_info_t *ci;

    ci = (char_info_t*)(_char_info+n);
    switch (ci->mode) {
    case MODE_BOTH:
	if (!math_label) to_text_mode(fp);
	if (math_mode) fprintf(fp, "%s", ci->math);
	else fprintf(fp, "%s", ci->text);
	break;
    case MODE_TEXT:
	if (math_label) {
	    fprintf(fp,"\\hbox{%s}",ci->text);
	} else {
	    to_text_mode(fp);
	    fprintf(fp, "%s", ci->text);
	}
	break;
    case MODE_MATH:
	to_math_mode(fp);
	fprintf(fp, "%s", ci->math);
	break;
    default:
	break;
    }
}

char *end_of_string(char *str)
{
    char *p = str;
    int end = 0;
    while (!end && *p) {
	if (*p=='\\') {
	    p++;
	    if (*p>='0' && *p<='7') {
		if (*p=='0' && *(p+1)=='0' && *(p+2)=='1') end=1;
		p+=3;
	    } else {
		p++;
	    }
	} else {
	    p++;
	}
    }
    return p;
}


int preinfo_text(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp)
{
    int i, n, x0, y0, x1, y1, ht, wd, subtype, depth;
    char *p, *q, *endstr;
    char buf[255];

    subtype = tscani(sp);
    into_colortbl(ctbl,tscani(sp)); // color
    depth = tscani(sp);
    tskipw(sp, 5);
    ht = (int)ceil(tscand(sp));
    wd = (int)ceil(tscand(sp));
    x0 = tscani(sp);
    y1 = tscani(sp);
    // skip string
    p = ttell(sp);
    endstr = end_of_string(p);
    sp->curpos = endstr;
    p++;
    /* Scan string and determine the necessary packages */
    for (q=p; q<endstr; ) {
	i = get_next_char(q,&q);
	n = _char_info[i].need;
	if (n) pkgs_needed[n]=1;
    }

    if (strncmp(p, XFIG_SPECIAL, STRLEN_XFIG_SPECIAL)) { // if plain text
	if (subtype==1) x0 -= wd/2;
	else if (subtype==2) x0 -= wd;

	x1 = x0+wd;
	y0 = y1-ht;

	if (x0<*xmin) *xmin=x0;
	if (y0<*ymin) *ymin=y0;
	if (x1>*xmax) *xmax=x1;
	if (y1>*ymax) *ymax=y1;
    } else { // if xfig source special for depth setting
	p += STRLEN_XFIG_SPECIAL;
	if (!strncmp(p, XFIG_DEPTH, STRLEN_XFIG_DEPTH)) {
	    global_depth = atoi(p+STRLEN_XFIG_DEPTH);
	}
    }
    return depth;
}

void proc_text(FILE *fp, STREAM *sp) /* 4 */
{
    int nchg, color, hasset=0, justify, depth, height, font, x, y, c;
    double fontsize, angle;
    char *p, *endptr;
    STYLE style;

    justify = tscani(sp);
    color = tscani(sp);
    depth = tscani(sp);
    tskipw(sp, 1);
    font = tscani(sp);
    fontsize = tscand(sp);
    angle = tscand(sp);
    tskipw(sp, 1);
    height = (int)tscand(sp);
    tskipw(sp, 1);
    x = tscani(sp);
    y = tscani(sp);
    p = ttell(sp);
    p++;
    endptr = end_of_string(p)-4;
    tsetpos(sp, endptr+4);

    if (strncmp(p, XFIG_SPECIAL, STRLEN_XFIG_SPECIAL)) { // if plain text
	fprintf(fp, "\n\\rput");
	if (justify==0) fprintf(fp, "[lB]");
	else if (justify==2) fprintf(fp, "[rB]");
	else fprintf(fp, "[B]");
	if (fabs(angle)>0.000001) fprintf(fp, "{%.0f}", RAD2DEG(angle));
	fprint_xy(fp, x, y);

	fputc('{', fp);
	latex_color_command(fp, color);

	if (math_label || font==32) to_math_mode(fp); // font==32: symbol
	while (p<endptr) {
	    c = get_next_char(p,&p);
	    if (font==32) fprintf(fp, "%s", symbol_table[c]);
	    else if (latex_symbols) print_tex_char(fp,c);
	    else fputc(_chars[c],fp);
	}
	to_text_mode(fp);
	fputc('}', fp);
    }
}
