/*
 * Copyright (c) 2004 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include "fig2pstricks.h"
#include "extern.h"

int preinfo_arc(int*colortbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp)
{
    int i, fa, ba, x, y, depth;
    tskipw(sp, 3);
    into_colortbl(colortbl,tscani(sp)); // linecolor
    into_colortbl(colortbl,tscani(sp)); // fillcolor
    depth = tscani(sp);
    tskipw(sp, 5);
    fa = tscani(sp);
    ba = tscani(sp);
    tskipw(sp, 2);
    for (i=0; i<3; i++) {
	x = tscani(sp);
	y = tscani(sp);
	if (x<*xmin) *xmin=x;
	else if (x>*xmax) *xmax=x;
	if (y<*ymin) *ymin=y;
	else if (y>*ymax) *ymax=y;
    }
    if (fa) tskipw(sp, 5);
    if (ba) tskipw(sp, 5);
    return depth;
}

void proc_arc(FILE *fout, STREAM *sp) /* 5 */
{
    int subtype, hasset=0, i, d[6], arrow[2], direct, fill, fa, ba;
    double v[6], cx, cy, r, dx, dy, angle;
    STYLE style;

    subtype = read_style(&style, sp);
    hasset = write_style(fout, &prev_style, &style);
    prev_style = style;
    psset_close(fout, hasset);

    tskipw(sp, 1);
    direct = tscani(sp);
    fa = tscani(sp);
    ba = tscani(sp);
    cx = tscand(sp);
    cy = tscand(sp);

    for (i=0; i<6; i++) { d[i]=tscani(sp); v[i]=d[i]; }

    fputc('\n', fout);
    if (subtype==1) fprintf(fout, "\\psarc");
    else fprintf(fout, "\\pswedge");
    if (star_style(&style)) fputc('*', fout);

    proc_arrows(fout, fa, ba, sp, subtype==1);
    fprint_xy(fout, (int)cx, (int)cy);

    if (direct==0) {
	double tmp;
	tmp=v[4]; v[4]=v[0]; v[0]=tmp;
	tmp=v[5]; v[5]=v[1]; v[1]=tmp;
    }

    dx = v[0]-cx;
    dy = cy-v[1];
    r = sqrt(dx*dx+dy*dy);
    fprintf(fout, "{%g}", unit2cm(r));
    angle = asin(dy/r);
    if (dx<0) angle=M_PI-angle;
    fprintf(fout, "{%.2f}", RAD2DEG(angle));

    dx = v[4]-cx;
    dy = cy-v[5];
    angle = asin(dy/r);
    if (dx<0) angle=M_PI-angle;
    fprintf(fout, "{%.2f}", RAD2DEG(angle));
}
