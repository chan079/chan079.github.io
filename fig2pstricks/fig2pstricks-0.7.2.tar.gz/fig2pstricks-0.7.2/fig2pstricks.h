/*
 * Copyright (c) 2004-2009 Chirok Han
 *
 * This file is part of fig2pstricks.
 *
 * Fig2pstricks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * Fig2pstricks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with fig2pstricks; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Contact: beanerjo@yahoo.com
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <limits.h>
/*#include <libgen.h>*/

#include "dtypes.h"

#ifndef fig2pstricks_h
#define fig2pstricks_h



/* file: arc.c */
int preinfo_arc(int*colortbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp);
void proc_arc(FILE *fout, STREAM *sp) /* 5 */;

/* file: arrow.c */
void read_arrow(ARROW *arrow, STREAM *stream);
void proc_arrows(FILE *fout, int nforward, int nbackward, STREAM *sp, int prt);

/* file: chkprev.c */
void chkprev_linestyle(FILE*fp,int*hasset,int nprev,int nnow,char*keyname);
void chkprev_fillstyle(FILE*fp,int*hasset,int nprev,int nnow,char*keyname);
void chkprev_thick(FILE *fp,int *hasset,int  nprev,int nnow,char *keyname);

/* file: color.c */
long rgb2long(int r, int g, int b);
void long2rgb(long rgb, int *r, int *g, int *b);
double col2f(int col);
void chkprev_color(FILE*fp,int *hasset,int nprev,int nnow,char *keyname);
void proc_color(FILE *fp, STREAM *sp);
void latex_color_command(FILE *fp, int c);
char *color_name(char *color_name_buf, int c);
void fprint_color_name(FILE *fp, int c);
int in_colortbl(int *colortbl, int c);
void into_colortbl(int *colortbl, int c);
void define_new_color(FILE *fp, long col, char *name, ...);
void proc_colortbl(FILE *fp, int *ctbl);
void show_colortbl(char *fmt, int *ctbl);
void fill_colortbl(int *ctbl, int c);

/* file: compound.c */
int preinfo_compound(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp);
void proc_compound(FILE *fp, STREAM *sp);

/* file: ellipse.c */
int preinfo_ellipse(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp);
void proc_ellipse(FILE *fp, STREAM *sp);
void proc_ellipse_dot(FILE *fp, STREAM *sp);

/* file: fig2pstricks.c */
void print_depth_help(FILE *fp, char *appname);
void print_help(FILE *fp, char *appname);
void print_version(FILE *fp, char *appname, char *version);
void error_exit(char *fmt, ...);
void proc_spec(FILE *fp, char *p);
void check_next_arg1(char *opt, int i, int argc, char *next_arg, char **ptr);
int get_one_scale(double *scale, char *ptr);
int get_one_unit(double *xcm, char *ptr) /* return 1 if error */;
int get_unit(double *xunit, double *yunit, char *ptr);
int get_scale(double *xscale, double *yscale, char *ptr);

/* file: misc.c */
char *trims(char *s);

/* file: node.c */
NODE create_node(int depth, char *ptr);
void delete_node(NODE pn);
NODE first_node(NODE pn);
NODE last_node(NODE pn);
void rewind_node(NODE *pn);
void windup_node(NODE *pn);
void append_node(NODE pn, int depth, char *ptr);
void prepend_node(NODE pn, int depth, char *ptr);
int sort_by_depth(NODE *pn) /* big to small */;
void print_node(NODE pn);

/* file: polyline.c */
int preinfo_polyline(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp);
void proc_polyline(FILE *fp, STREAM *sp) /* 2 */;

/* file: spline.c */
int preinfo_spline(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp);
void proc_spline(FILE*fp, STREAM*sp);

/* file: style.c */
int read_style(STYLE *style, STREAM *stream);
int write_style(FILE *fp, STYLE *prev, STYLE *cur);
int star_style(STYLE *sty);
void init_style(STYLE *sty);
void clean_style(STYLE *s);

/* file: texfunc.c */
void texcomment(FILE *fp, char *fmt, ...);
void psset_if_nec(FILE *fp, int *hasset);
void psset_close(FILE *fp, int hasset);

/* file: text.c */
int get_next_char(char *p, char **endptr);
void to_math_mode(FILE *fp);
void to_text_mode(FILE *fp);
void print_tex_char(FILE *fp, int n);
char *end_of_string(char *str);
int preinfo_text(int*ctbl,int*xmin,int*ymin,int*xmax,int*ymax,STREAM*sp);
void proc_text(FILE *fp, STREAM *sp) /* 4 */;

/* file: tscan.c */
STREAM *topen(char *ptr, int n);
void tclose(STREAM *sp);
void trelink(STREAM *sp, char *ptr, int n);
void trewind(STREAM *sp);
void twindup(STREAM *sp);
long tlength(STREAM *sp);
int tntell(STREAM *sp);
int ttellln(STREAM *sp);
char *ttell(STREAM *sp);
char *tsetpos(STREAM *sp, char *p);
void tseek(STREAM *sp, long npos, int whence);
int tsetnpos(STREAM *sp, int n);
int tscani(STREAM *sp);
unsigned int tscanu(STREAM *sp);
double tscand(STREAM *sp);
char *tscans(char *ptr, STREAM *sp);
char *tunscan(STREAM *sp);
char *tnexttok(char *ptr, STREAM *sp) /* Does not proceed pointer */;
char *tskipw(STREAM *sp, int n);

/* file: unit.c */
double unit2cm(int x);
double thick2cm(int x);
void fprint_xy(FILE *fp, int nx, int ny);
void fprint_xy4(FILE *fp, int nx, int ny, int ybdry);
void fprint_xy_cm(FILE *fp, int nx, int ny);
void fprint_xy_cm4(FILE *fp, int nx, int ny, int ybdry);

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)>(b)?(b):(a))

#define MAXSIZE 255
#define MAXCSIZE 63
#define MAXCOLOR 512

#define INT2CCN(n) ((n)-32)
#define RAD2DEG(r) ((r)*180/M_PI)

#define OBJ_COLOR    0
#define OBJ_ELLIPSE  1
#define OBJ_POLYLINE 2
#define OBJ_SPLINE   3
#define OBJ_TEXT     4
#define OBJ_ARC      5
#define OBJ_COMPOUND 6

#define UNIT_CM      0
#define UNIT_IN      1
#define UNIT_PT      2
#define UNIT_MM      3

#define XFIG_SPECIAL "##%% "
#define STRLEN_XFIG_SPECIAL 5
#define XFIG_DEPTH "depth="
#define STRLEN_XFIG_DEPTH 6

#endif

